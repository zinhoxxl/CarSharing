package model.payment;

public class PaymentDAO {

}
