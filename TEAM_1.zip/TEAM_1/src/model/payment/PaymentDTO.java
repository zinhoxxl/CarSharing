package model.payment;

public class PaymentDTO {

}
