package model.reservation;

public class ReservationDTO {

}
