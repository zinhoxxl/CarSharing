package model.carManagement;

public class carManagementDTO {

}
